from ..structwrapper import BinReader
from ..wmb import wmb_importer
import bpy
import os
import mathutils, math


def ImportSCR(filepath):
    rawf = open(filepath, "rb")

    extracted_wmb_dir = os.path.join(os.path.dirname(filepath), "b2b_scr_extracted", os.path.basename(filepath))
    os.makedirs(extracted_wmb_dir, exist_ok=True)


    f = BinReader(rawf)

    if not (f.read(4).decode() == "SCR\x00"):
        print("Not an SCR!")
        return {'CANCELLED'}
    
    print("Importing SCR...")


    if ("SCR" not in bpy.data.collections):
        scr_collection = bpy.data.collections.new("SCR")
        bpy.context.scene.collection.children.link(scr_collection)
    else:
        scr_collection = bpy.data.collections["SCR"]

    model_count = f.read_u32()
    offset_textures = f.read_u32()
    tag = f.read_u32()
    if (tag!=1):
        print("WARNING! Odd tag for Bayonetta 1!")

    wmb_offsets = []
    f.seek(0x10)
    for i in range(model_count):
        f.seek(0x14+(i*140))
        wmb_offsets.append(f.read_u32())
    wmb_offsets.append(offset_textures)


    f.seek(0x10)
    for i in range(model_count):
        f.seek(0x10+(i*140))
        scr_name = f.read(16).decode().replace("\x00", "")
        offset = f.read_u32() + 0x10+(i*140)
        translation = f.read_f32_vector3()
        rotation = f.read_f32_vector3()
        scale = f.read_f32_vector3()
        paramsA = f.read_s16_array(8)
        flags = f.read_u32()
        paramsB = f.read_s16_array(32)





        f.seek(offset)
        wmb_data = f.read(wmb_offsets[i+1]-offset)
        wmb_path = os.path.join(extracted_wmb_dir, f"{scr_name}.wmb")
        x = open(os.path.join(extracted_wmb_dir, f"{scr_name}.wmb"), "wb")
        x.write(wmb_data)
        x.close()

        wmb_importer.ImportWMB(wmb_path, "", False, False, target_col="SCR")

        model_collection = bpy.data.collections.get(scr_name)
        model_collection["flags"] = flags
        model_collection["paramsA"] = paramsA
        model_collection["paramsB"] = paramsB

        for obj in model_collection.objects:
            if obj.type == 'MESH':
                obj.location = mathutils.Vector(translation)
                obj.scale = mathutils.Vector(scale)



    return {'FINISHED'}
